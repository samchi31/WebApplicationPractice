package kr.or.ddit.dao;

import org.springframework.stereotype.Repository;

@Repository
public class SampleDAO {
	public String selectData() {
		return "RAW DATA";
	}
}
